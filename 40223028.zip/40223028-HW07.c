// 40223028 - Zahra Heydari
//HW07
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int compareStrings(char str1[],char str2[]);
int main()
{
    // get number and words of both languages
    int n;
    printf("please enter the number of words: ");
    scanf("%d",&n);
    char language1[n][50];
    char language2[n][50];
    printf("please enter the words:(language1(4 spaces)language2)\n");
    for (int i=0 ; i<n ; i++)
    {
        scanf("%s    %s",language1[i],language2[i]);
    }
    
    // upper or lower
    int letters = 0; // 0 means lower and 1 means upper
    char lowercase = tolower(language1[0][0]);
    char uppercase = toupper(language1[0][0]);
    if (lowercase == language1[0][0]){
        letters = 1;
    }
    // get the string of words
    char string[1000] = {};
    printf("\nplease enter string: ");
    getchar();
    fgets(string,sizeof(string),stdin);
    

    for (int i=0 ; i < strlen(string)-1 ; i++)
    {
        if (letters == 1){
                string[i] = tolower(string[i]);
        }else{
                string[i] = toupper(string[i]);
            }
    }
    


    // sepratre the words
    char words[100][50] ={};
    int word_p = 0;
    int char_p = 0;
    for (int i=0 ; i < strlen(string)-1 ; i++)
    {
        if (string[i] != ' ')
        {
            words[word_p][char_p] = string[i];
            char_p ++;
        }
        else
        {
            words[word_p][char_p] = '\0';
            word_p ++;
            char_p = 0;
        }
        
    }
    

    // finding the words and replace them if needed
    int flag = 0; // if falg = 1 we found the word in the first list
    int stop = 1; // if stop = 0 the proogram will not continue
    for (int i=0 ; i <= word_p ; i++)
    {
        for (int j=0 ; j < n ; j++)
        {
            if (compareStrings(words[i],language1[j]) == 0)
            {
                flag = 1;
                if (strlen(language1[j]) > strlen(language2[j]))
                {
                    
                    strcpy(words[i],language2[j]);
                    break;
                }
            }
            else if (compareStrings(words[i],language2[j]) == 0)
            {             
                flag = 1;
                if (strlen(language1[j]) < strlen(language2[j]))
                {
                    
                    strcpy(words[i],language1[j]);
                    break;
                }
            }
            
        }
        // if flag is 1 then we found the word in the first list but if flag is 0 we couldn't find the word
        if (flag == 0){
            printf("\n%s was not in the first list.",words[i]);
            stop = 0;
        }
        flag = 0;
    }

    

    // printing the results
    if (stop == 1)
    {
        printf("\nTranslated string:\n");
        for (int i=0 ; i <= word_p ; i++)
        {
            printf("%s ",words[i]);
        }
    }
    
    return 0;
}

int compareStrings(char str1[],char str2[])
{
    int i = 0;
    while ((str1[i] != '\0') || (str2[i] != '\0'))
    {
        if (str1[i] != str2[i]){
            return 1; // strings are different
        }
        i++;
    }
    // check if the lenghts are the same
    if ((str1[i] == '\0') && (str2[i] == '\0')){
        return 0; // strings are the same
    }else{
        return 1; // strings are different in lenght
    }

}